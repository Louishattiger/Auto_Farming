Obtention de ces images:

rotation : 30 deg
encodage : grayscale
taille   : 91 * 51

langage utilisé: python
biblio  utilisé: cv2

 